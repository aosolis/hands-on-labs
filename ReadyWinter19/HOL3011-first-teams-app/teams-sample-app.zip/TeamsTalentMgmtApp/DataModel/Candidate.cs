﻿namespace TeamsTalentMgmtApp.DataModel
{
    public class Candidate
    {
        public string Name { get; set; }
        public int Hires { get; set; }
        public int NoHires { get; set; }
        public string Stage { get; set; }
        public string ReqId { get; set; }
        public string CurrentRole { get; set; }
        public string ProfilePicture { get; set; }
    }
}