﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("3.15.2.0")]
[assembly: AssemblyFileVersion("3.15.2.0")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
//[assembly: AssemblyDelaySignAttribute(true)]

[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
 [assembly: AssemblyDelaySignAttribute(true)]
